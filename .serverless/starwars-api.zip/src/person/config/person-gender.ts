import { PersonGender } from "@prisma/client";

export const PersonGenderList = [
    PersonGender.NA,
    PersonGender.female,
    PersonGender.male,
];