export * from './pagination-response.interface';
export * from './planet-response.interface';
export * from './people-response.interface';