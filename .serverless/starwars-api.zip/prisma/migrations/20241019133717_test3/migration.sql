/*
  Warnings:

  - You are about to drop the column `url` on the `Planet` table. All the data in the column will be lost.

*/
-- AlterTable
ALTER TABLE `Planet` DROP COLUMN `url`;
